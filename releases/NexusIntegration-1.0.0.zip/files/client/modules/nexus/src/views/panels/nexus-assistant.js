/**
 * nexus-assistant panel — "Ask NEXUS" side panel on Contact/Account/Lead/Case detail views.
 *
 * Uses the synchronous /api/v1/nexus/chat endpoint for quick queries.
 * Falls back to showing a queue-submit form when the chat endpoint returns
 * a timeout (status 0 or 502) so the user can submit async instead.
 */
import View from 'view';

export default class NexusAssistantView extends View {

    templateContent = `
        <div class="nexus-assistant" style="padding: 8px 0;">
            {{#unless nexusEnabled}}
            <div class="alert alert-warning" style="font-size:12px;padding:6px 10px;margin:0 0 8px;">
                NEXUS is disabled. Enable it in
                <a href="#Admin/nexusSettings">Admin &rsaquo; NEXUS Settings</a>.
            </div>
            {{/unless}}

            <div class="nexus-input-area" style="margin-bottom:8px;">
                <textarea
                    class="form-control nexus-prompt"
                    rows="3"
                    placeholder="Ask NEXUS about this record..."
                    style="resize:vertical; font-size:13px;"
                    {{#unless nexusEnabled}}disabled{{/unless}}
                ></textarea>
            </div>

            <div style="display:flex; gap:6px; align-items:center; margin-bottom:8px;">
                <button class="btn btn-default btn-sm" data-action="nexusAsk"
                    {{#unless nexusEnabled}}disabled{{/unless}}>
                    <span class="fas fa-brain" style="margin-right:4px;color:#2b7de9;"></span>Ask
                </button>
                <button class="btn btn-link btn-sm nexus-cancel-btn"
                    data-action="nexusCancel" style="display:none;">
                    Cancel
                </button>
                <span class="nexus-loading" style="display:none;font-size:12px;color:#888;">
                    <span class="fas fa-spinner fa-spin"></span> Asking NEXUS&hellip;
                </span>
            </div>

            <div class="nexus-error alert alert-danger"
                style="display:none;font-size:12px;padding:6px 10px;margin-bottom:8px;"></div>

            <div class="nexus-result" style="display:none;">
                <div class="nexus-result-meta"
                    style="font-size:11px;color:#999;margin-bottom:4px;"></div>
                <div class="nexus-result-text"
                    style="white-space:pre-wrap;font-size:13px;background:#f8f8f8;
                           padding:10px;border-radius:4px;border:1px solid #e0e0e0;
                           max-height:300px;overflow-y:auto;"></div>
            </div>

            {{#if nexusEnabled}}
            <div class="nexus-queue-fallback" style="display:none; margin-top:8px;">
                <small class="text-muted">
                    Chat timed out.
                    <a href="#" data-action="nexusSubmitQueue">Submit as background job</a>
                    instead.
                </small>
            </div>
            {{/if}}
        </div>
    `;

    events = {
        'click [data-action="nexusAsk"]':         'onAsk',
        'click [data-action="nexusCancel"]':       'onCancel',
        'click [data-action="nexusSubmitQueue"]':  'onSubmitQueue',
        'keydown .nexus-prompt':                   'onKeydown',
    };

    /** @type {string|null} */
    _lastPrompt = null;

    data() {
        return {
            nexusEnabled: this.getConfig().get('nexusEnabled') !== false,
        };
    }

    onAsk() {
        const prompt = this.$el.find('.nexus-prompt').val().trim();
        if (!prompt) return;

        this._lastPrompt = prompt;
        this._setLoading(true);
        this.$el.find('.nexus-error').hide();
        this.$el.find('.nexus-result').hide();
        this.$el.find('.nexus-queue-fallback').hide();

        this.ajaxPostRequest('nexus/chat', {
            message:    prompt,
            entityType: this.model.entityType,
            entityId:   this.model.id,
        })
        .then(result => this._showResult(result))
        .catch(xhr => {
            const isTimeout = xhr.status === 0 || xhr.status === 502 || xhr.status === 504;
            const msg = isTimeout
                ? 'NEXUS did not respond in time.'
                : (xhr.responseJSON?.error || 'NEXUS request failed.');
            this.$el.find('.nexus-error').text(msg).show();
            if (isTimeout) {
                this.$el.find('.nexus-queue-fallback').show();
            }
        })
        .finally(() => this._setLoading(false));
    }

    onCancel() {
        this._setLoading(false);
    }

    /** Submit the last prompt as an async queue job. */
    onSubmitQueue(e) {
        e.preventDefault();
        if (!this._lastPrompt) return;

        this.$el.find('.nexus-queue-fallback').hide();
        this.$el.find('.nexus-error').hide();

        this.ajaxPostRequest('nexus/submit', {
            prompt:     this._lastPrompt,
            urgency:    'normal',
            label:      `EspoCRM ${this.model.entityType} ${this.model.id}`,
            context: {
                entityType: this.model.entityType,
                entityId:   this.model.id,
            },
        })
        .then(result => {
            const jobId = result.job_id;
            this.$el.find('.nexus-result-meta').text(`Job ${jobId} queued — polling for result…`);
            this.$el.find('.nexus-result-text').text('');
            this.$el.find('.nexus-result').show();
            this._pollJob(jobId, 0);
        })
        .catch(xhr => {
            const msg = xhr.responseJSON?.error || 'Failed to submit queue job.';
            this.$el.find('.nexus-error').text(msg).show();
        });
    }

    /** Poll /nexus/result/:jobId until completed or failed (max 40 attempts × 3s = 2min). */
    _pollJob(jobId, attempts) {
        if (attempts > 40) {
            this.$el.find('.nexus-result-meta').text(`Job ${jobId} — timed out waiting for result.`);
            return;
        }

        setTimeout(() => {
            this.ajaxGetRequest(`nexus/result/${encodeURIComponent(jobId)}`)
            .then(result => {
                const status = result.status;
                if (status === 'completed') {
                    this._showResult(result);
                } else if (status === 'failed') {
                    this.$el.find('.nexus-result-meta').text(`Job ${jobId} failed.`);
                    this.$el.find('.nexus-result-text').text(result.error_message || '');
                } else {
                    this.$el.find('.nexus-result-meta').text(
                        `Job ${jobId} — ${status}… (attempt ${attempts + 1})`
                    );
                    this._pollJob(jobId, attempts + 1);
                }
            })
            .catch(() => this._pollJob(jobId, attempts + 1));
        }, 3000);
    }

    onKeydown(e) {
        // Ctrl/Cmd+Enter submits
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            this.onAsk();
        }
    }

    _setLoading(loading) {
        this.$el.find('[data-action="nexusAsk"]').prop('disabled', loading);
        this.$el.find('.nexus-cancel-btn').toggle(loading);
        this.$el.find('.nexus-loading').toggle(loading);
    }

    _showResult(result) {
        const text  = result.reply
            || result.result_text
            || result.response
            || result.content
            || JSON.stringify(result, null, 2);

        const parts = [];
        if (result.model_used || result.model) parts.push(result.model_used || result.model);
        if (result.tier_used)                   parts.push(result.tier_used);
        if (result.session_id)                  parts.push(`session: ${result.session_id}`);

        this.$el.find('.nexus-result-meta').text(parts.join(' · '));
        this.$el.find('.nexus-result-text').text(text);
        this.$el.find('.nexus-result').show();
    }
}
