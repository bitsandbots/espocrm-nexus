/**
 * NEXUS Settings — admin page view.
 *
 * Registered as the view for #Admin/nexusSettings.
 * Reads/writes settings via the NexusGateway controller.
 */
import View from 'view';

export default class NexusSettingsView extends View {

    templateContent = `
        <div class="page-header">
            <h3>
                <span class="fas fa-brain" style="color:#2b7de9;margin-right:8px;"></span>
                NEXUS Integration Settings
            </h3>
        </div>

        <div class="panel panel-default">
            <div class="panel-body">

                <div class="row">
                    <div class="col-sm-6">

                        <div class="form-group">
                            <label class="control-label">NEXUS URL</label>
                            <input type="text" class="form-control" name="nexusUrl"
                                value="{{nexusUrl}}"
                                placeholder="http://potpie.local:5000">
                        </div>

                        <div class="form-group">
                            <label class="control-label">Username</label>
                            <input type="text" class="form-control" name="nexusUsername"
                                value="{{nexusUsername}}"
                                autocomplete="off">
                        </div>

                        <div class="form-group">
                            <label class="control-label">Password</label>
                            <input type="password" class="form-control" name="nexusPassword"
                                placeholder="Leave blank to keep existing password"
                                autocomplete="new-password">
                        </div>

                        <div class="form-group">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="nexusEnabled"
                                        {{#if nexusEnabled}}checked{{/if}}>
                                    Enable NEXUS Integration
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="nexusRagEnabled"
                                        {{#if nexusRagEnabled}}checked{{/if}}>
                                    Auto-ingest records into NEXUS knowledge base (RAG)
                                </label>
                                <small class="text-muted" style="display:block;margin-top:2px;margin-left:20px;">
                                    When enabled, Contact/Account/Lead/Case saves are pushed to NEXUS
                                    so the AI assistant has current CRM context.
                                </small>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="nexus-status-bar" style="min-height:24px;margin-bottom:12px;font-size:13px;">
                    {{#if statusMsg}}{{{statusMsg}}}{{/if}}
                </div>

                <div style="display:flex;gap:8px;">
                    <button class="btn btn-primary" data-action="save">Save</button>
                    <button class="btn btn-default" data-action="testConnection">
                        <span class="fas fa-plug" style="margin-right:4px;"></span>Test Connection
                    </button>
                </div>

            </div>
        </div>
    `;

    events = {
        'click [data-action="save"]':           'onSave',
        'click [data-action="testConnection"]': 'onTest',
    };

    /** @type {Record<string, any>} */
    nexusSettings = {};

    /** @type {string} */
    statusMsg = '';

    data() {
        return {
            nexusUrl:        this.nexusSettings.nexusUrl        ?? 'http://potpie.local:5000',
            nexusUsername:   this.nexusSettings.nexusUsername   ?? '',
            nexusEnabled:    this.nexusSettings.nexusEnabled    ?? false,
            nexusRagEnabled: this.nexusSettings.nexusRagEnabled ?? true,
            statusMsg:       this.statusMsg,
        };
    }

    setup() {
        this.ajaxGetRequest('nexus/settings')
            .then(data => {
                this.nexusSettings = data;
                this.reRender();
            })
            .catch(() => {
                this.statusMsg =
                    '<span class="text-warning fas fa-exclamation-triangle"></span> ' +
                    'Could not load current settings.';
                this.reRender();
            });
    }

    onSave() {
        const $btn = this.$el.find('[data-action="save"]').prop('disabled', true);

        const payload = {
            nexusUrl:        this.$el.find('[name="nexusUrl"]').val().trim(),
            nexusUsername:   this.$el.find('[name="nexusUsername"]').val().trim(),
            nexusEnabled:    this.$el.find('[name="nexusEnabled"]').is(':checked'),
            nexusRagEnabled: this.$el.find('[name="nexusRagEnabled"]').is(':checked'),
        };

        const password = this.$el.find('[name="nexusPassword"]').val();
        if (password) {
            payload.nexusPassword = password;
        }

        this.ajaxRequest('nexus/settings', 'PUT', JSON.stringify(payload))
            .then(() => {
                this.nexusSettings = Object.assign({}, this.nexusSettings, payload);
                this._setStatus(
                    '<span class="fas fa-check-circle text-success"></span> Settings saved.',
                );
                this.notify(this.translate('Saved'), 'success');
            })
            .catch(xhr => {
                const msg = xhr.responseJSON?.error || 'Save failed.';
                this._setStatus(
                    `<span class="fas fa-times-circle text-danger"></span> ${msg}`
                );
            })
            .finally(() => $btn.prop('disabled', false));
    }

    onTest() {
        this._setStatus('<span class="fas fa-spinner fa-spin"></span> Testing connection…');

        this.ajaxGetRequest('nexus/health')
            .then(data => {
                if (data.healthy) {
                    this._setStatus(
                        '<span class="fas fa-check-circle text-success"></span> NEXUS is reachable.'
                    );
                } else {
                    this._setStatus(
                        '<span class="fas fa-times-circle text-danger"></span> NEXUS responded but reports unhealthy.'
                    );
                }
            })
            .catch(() => {
                this._setStatus(
                    '<span class="fas fa-times-circle text-danger"></span> Could not connect to NEXUS.'
                );
            });
    }

    _setStatus(html) {
        this.$el.find('.nexus-status-bar').html(html);
    }
}
